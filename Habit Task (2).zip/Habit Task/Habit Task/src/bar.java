import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class bar extends JPanel {
  private JProgressBar progressBar;

  public bar() {
    // Create the progress bar
    progressBar = new JProgressBar(0, 100);
    progressBar.setValue(0);
    progressBar.setStringPainted(true);

    // Add the progress bar to the panel
    add(progressBar);
  }

  public void setProgress(int progress) {
    // Set the progress value of the progress bar
    progressBar.setValue(progress);
  }

  public static void main(String[] args) {
    JFrame frame = new JFrame("Progress Bar Example");
    bar panel = new bar();
    frame.getContentPane().add(panel);

    // Set the size of the window
    frame.setSize(300, 100);

    // Set the window to be visible
    frame.setVisible(true);
    // Update the progress bar
    for (int i = 0; i <= 100; i++) {
      panel.setProgress(i);
      try {
        Thread.sleep(100);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
}


