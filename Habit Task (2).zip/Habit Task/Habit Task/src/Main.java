import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.plaf.DimensionUIResource;

//Wichayaporn Punnodaka[6530301003]

public class Main {
	
	public static void main(String args[])
	{
		Frame frame = new Frame();
	}
}